<?php
header('Content-Type: application/json');
require_once 'config.php';

// Get JSON data from request
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'داده نامعتبر است']);
    exit;
}

try {
    // Start transaction
    $pdo->beginTransaction();

    // Insert form
    $stmt = $pdo->prepare("
        INSERT INTO forms (title, created_at) 
        VALUES (?, NOW())
    ");
    $stmt->execute(['فرم جدید']);
    $formId = $pdo->lastInsertId();

    // Insert form fields
    $stmt = $pdo->prepare("
        INSERT INTO form_fields 
        (form_id, field_type, label, field_name, placeholder, is_required, min_length, max_length, options) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    foreach ($data['fields'] as $field) {
        $options = isset($field['options']) ? json_encode($field['options'], JSON_UNESCAPED_UNICODE) : null;
        
        $stmt->execute([
            $formId,
            $field['type'],
            $field['label'],
            $field['name'],
            $field['placeholder'],
            $field['required'] ? 1 : 0,
            $field['minLength'] ?? null,
            $field['maxLength'] ?? null,
            $options
        ]);
    }

    // Commit transaction
    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'فرم با موفقیت ذخیره شد',
        'form_id' => $formId
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    $pdo->rollBack();
    
    echo json_encode([
        'success' => false,
        'message' => 'خطا در ذخیره فرم: ' . $e->getMessage()
    ]);
} 