document.addEventListener('DOMContentLoaded', function() {
    const formContainer = document.getElementById('formContainer');
    const propertiesContainer = document.getElementById('propertiesContainer');
    const previewBtn = document.getElementById('previewBtn');
    const saveBtn = document.getElementById('saveBtn');
    let selectedField = null;

    // Add click event to sidebar elements
    document.querySelectorAll('.element').forEach(element => {
        element.addEventListener('click', function() {
            const type = this.getAttribute('data-type');
            createFormField(type);
        });
    });

    function createFormField(type) {
        const field = document.createElement('div');
        field.className = 'form-field bg-white rounded-xl p-6 mb-6 relative shadow-lg hover:shadow-xl transition-all duration-300 border border-primary-100 group';
        field.setAttribute('data-type', type);

        const fieldContent = document.createElement('div');
        fieldContent.className = 'field-content';

        const fieldActions = document.createElement('div');
        fieldActions.className = 'absolute top-4 left-4 hidden gap-2 group-hover:flex';
        fieldActions.innerHTML = `
            <button class="p-2 rounded-lg bg-white border border-primary-100 text-primary-600 hover:bg-primary-600 hover:text-white transition-all duration-300">
                <i class="fas fa-edit"></i>
            </button>
            <button class="p-2 rounded-lg bg-white border border-primary-100 text-red-500 hover:bg-red-500 hover:text-white transition-all duration-300">
                <i class="fas fa-trash"></i>
            </button>
        `;

        let fieldHTML = '';
        switch(type) {
            case 'text':
                fieldHTML = `
                    <label class="block text-primary-800 font-medium mb-2">فیلد متنی</label>
                    <input type="text" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" placeholder="متن خود را وارد کنید">
                `;
                break;
            case 'number':
                fieldHTML = `
                    <label class="block text-primary-800 font-medium mb-2">فیلد عددی</label>
                    <input type="number" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" placeholder="عدد را وارد کنید">
                `;
                break;
            case 'email':
                fieldHTML = `
                    <label class="block text-primary-800 font-medium mb-2">ایمیل</label>
                    <input type="email" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" placeholder="ایمیل خود را وارد کنید">
                `;
                break;
            case 'textarea':
                fieldHTML = `
                    <label class="block text-primary-800 font-medium mb-2">متن چند خطی</label>
                    <textarea class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" rows="3" placeholder="متن خود را وارد کنید"></textarea>
                `;
                break;
            case 'select':
                fieldHTML = `
                    <label class="block text-primary-800 font-medium mb-2">لیست کشویی</label>
                    <select class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300">
                        <option value="">انتخاب کنید</option>
                        <option value="1">گزینه ۱</option>
                        <option value="2">گزینه ۲</option>
                    </select>
                `;
                break;
            case 'checkbox':
                fieldHTML = `
                    <div class="flex items-center gap-2">
                        <input type="checkbox" class="w-5 h-5 rounded border-primary-300 text-primary-600 focus:ring-primary-500">
                        <label class="text-primary-800 font-medium">چک باکس</label>
                    </div>
                `;
                break;
            case 'radio':
                fieldHTML = `
                    <div class="flex items-center gap-2">
                        <input type="radio" name="radio1" class="w-5 h-5 border-primary-300 text-primary-600 focus:ring-primary-500">
                        <label class="text-primary-800 font-medium">رادیو باتن</label>
                    </div>
                `;
                break;
            case 'file':
                fieldHTML = `
                    <label class="block text-primary-800 font-medium mb-2">آپلود فایل</label>
                    <input type="file" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300">
                `;
                break;
            case 'date':
                fieldHTML = `
                    <label class="block text-primary-800 font-medium mb-2">تاریخ</label>
                    <input type="date" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300">
                `;
                break;
        }

        fieldContent.innerHTML = fieldHTML;
        field.appendChild(fieldActions);
        field.appendChild(fieldContent);
        formContainer.appendChild(field);

        // Add event listeners for field actions
        field.querySelector('button:first-child').addEventListener('click', () => {
            document.querySelectorAll('.form-field').forEach(f => f.classList.remove('selected'));
            field.classList.add('selected');
            showProperties(field);
        });
        
        field.querySelector('button:last-child').addEventListener('click', () => {
            field.remove();
            if (selectedField === field) {
                selectedField = null;
                propertiesContainer.innerHTML = '<p class="text-primary-500">یک فیلد را انتخاب کنید</p>';
            }
        });

        // Add click event to select field
        field.addEventListener('click', (e) => {
            if (!e.target.closest('button')) {
                document.querySelectorAll('.form-field').forEach(f => f.classList.remove('selected'));
                field.classList.add('selected');
                showProperties(field);
            }
        });

        // Show properties panel for the new field
        showProperties(field);
    }

    function showProperties(field) {
        selectedField = field;
        const type = field.getAttribute('data-type');
        let propertiesHTML = '';

        // Common properties for all fields
        propertiesHTML = `
            <div class="bg-primary-50 rounded-xl p-4 mb-4 border border-primary-100">
                <label class="block text-primary-800 font-medium mb-2">عنوان فیلد</label>
                <input type="text" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" 
                    value="${field.querySelector('label')?.textContent || ''}" 
                    onchange="updateFieldProperty('label', this.value)">
            </div>
            <div class="bg-primary-50 rounded-xl p-4 mb-4 border border-primary-100">
                <label class="block text-primary-800 font-medium mb-2">نام فیلد</label>
                <input type="text" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" 
                    value="${field.querySelector('input, select, textarea')?.name || ''}"
                    onchange="updateFieldProperty('name', this.value)">
            </div>
            <div class="bg-primary-50 rounded-xl p-4 mb-4 border border-primary-100">
                <label class="block text-primary-800 font-medium mb-2">توضیحات</label>
                <input type="text" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" 
                    value="${field.querySelector('input, select, textarea')?.placeholder || ''}"
                    onchange="updateFieldProperty('placeholder', this.value)">
            </div>
        `;

        // Type-specific properties
        switch(type) {
            case 'text':
            case 'email':
            case 'number':
                propertiesHTML += `
                    <div class="bg-primary-50 rounded-xl p-4 mb-4 border border-primary-100">
                        <label class="block text-primary-800 font-medium mb-2">حداقل طول</label>
                        <input type="number" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" 
                            value="${field.querySelector('input')?.minLength || ''}"
                            onchange="updateFieldProperty('minLength', this.value)">
                    </div>
                    <div class="bg-primary-50 rounded-xl p-4 mb-4 border border-primary-100">
                        <label class="block text-primary-800 font-medium mb-2">حداکثر طول</label>
                        <input type="number" class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" 
                            value="${field.querySelector('input')?.maxLength || ''}"
                            onchange="updateFieldProperty('maxLength', this.value)">
                    </div>
                `;
                break;
            case 'select':
                propertiesHTML += `
                    <div class="bg-primary-50 rounded-xl p-4 mb-4 border border-primary-100">
                        <label class="block text-primary-800 font-medium mb-2">گزینه‌ها</label>
                        <textarea class="w-full px-4 py-2 rounded-lg border border-primary-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 transition-all duration-300" 
                            rows="3" onchange="updateSelectOptions(this.value)">${Array.from(field.querySelectorAll('option')).map(opt => opt.textContent).join('\n')}</textarea>
                    </div>
                `;
                break;
        }

        propertiesHTML += `
            <div class="bg-primary-50 rounded-xl p-4 mb-4 border border-primary-100">
                <label class="block text-primary-800 font-medium mb-2">اجباری</label>
                <div class="flex items-center">
                    <input type="checkbox" class="w-5 h-5 rounded border-primary-300 text-primary-600 focus:ring-primary-500" 
                        ${field.querySelector('input, select, textarea')?.required ? 'checked' : ''}
                        onchange="updateFieldProperty('required', this.checked)">
                </div>
            </div>
        `;

        propertiesContainer.innerHTML = propertiesHTML;
    }

    // Preview functionality
    previewBtn.addEventListener('click', function() {
        const previewForm = document.getElementById('previewForm');
        const formHTML = formContainer.innerHTML;
        
        // Clean up the form HTML before setting it to preview
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = formHTML;
        
        // Remove empty state message
        const emptyStateMessage = tempDiv.querySelector('#formContainer:empty::before');
        if (emptyStateMessage) {
            emptyStateMessage.remove();
        }
        
        previewForm.innerHTML = tempDiv.innerHTML;
        
        // Clean up the form for preview
        previewForm.querySelectorAll('.form-field').forEach(field => {
            // Remove edit buttons
            field.querySelector('.field-actions')?.remove();
            
            // Remove selected class and empty state
            field.classList.remove('selected', 'group');
            field.querySelector('.empty-state')?.remove();
            
            // Update field styles
            field.className = 'form-field bg-white rounded-xl p-6 mb-6 relative shadow-lg border border-primary-100';
            
            // Make inputs interactive
            field.querySelectorAll('input, select, textarea').forEach(input => {
                input.disabled = false;
                input.readOnly = false;
                input.className = input.className.replace('focus:ring-2', 'focus:ring-1');
            });
        });

        // Show modal
        const modal = document.getElementById('previewModal');
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    });

    // Close modal function
    window.closePreviewModal = function() {
        const modal = document.getElementById('previewModal');
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    // Close modal when clicking outside
    document.getElementById('previewModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closePreviewModal();
        }
    });

    // Close modal with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closePreviewModal();
        }
    });

    // Save functionality
    saveBtn.addEventListener('click', function() {
        const formData = {
            fields: Array.from(formContainer.querySelectorAll('.form-field')).map(field => ({
                type: field.getAttribute('data-type'),
                label: field.querySelector('label')?.textContent,
                name: field.querySelector('input, select, textarea')?.name,
                placeholder: field.querySelector('input, select, textarea')?.placeholder,
                required: field.querySelector('input, select, textarea')?.required,
                options: field.querySelector('select') ? 
                    Array.from(field.querySelectorAll('option')).map(opt => ({
                        value: opt.value,
                        text: opt.textContent
                    })) : null
            }))
        };

        // Send to server
        fetch('save_form.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                alert('فرم با موفقیت ذخیره شد');
            } else {
                alert('خطا در ذخیره فرم');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('خطا در ذخیره فرم');
        });
    });
});

// Global functions for property updates
function updateFieldProperty(property, value) {
    const field = document.querySelector('.form-field.selected');
    if (!field) return;

    const input = field.querySelector('input, select, textarea');
    if (!input) return;

    switch(property) {
        case 'label':
            field.querySelector('label').textContent = value;
            break;
        case 'name':
            input.name = value;
            break;
        case 'placeholder':
            input.placeholder = value;
            break;
        case 'required':
            input.required = value;
            break;
        case 'minLength':
            input.minLength = value;
            break;
        case 'maxLength':
            input.maxLength = value;
            break;
    }
}

function updateSelectOptions(value) {
    const field = document.querySelector('.form-field.selected');
    if (!field) return;

    const select = field.querySelector('select');
    if (!select) return;

    const options = value.split('\n').filter(opt => opt.trim());
    select.innerHTML = '<option value="">انتخاب کنید</option>' + 
        options.map((opt, index) => `<option value="${index + 1}">${opt}</option>`).join('');
} 