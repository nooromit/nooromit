<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سازنده فرم حرفه‌ای</title>
    <!-- Vazir Font -->
    <link href="https://cdn.fontcdn.ir/Font/Persian/Vazir/Vazir.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-papmQv7K6QwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQwQw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Bootstrap RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        body { background: linear-gradient(135deg, #f8ffae 0%, #43c6ac 100%) !important; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 sidebar">
                <h3 class="text-center mb-4">عناصر فرم</h3>
                <div class="form-elements">
                    <div class="element" draggable="true" data-type="text">
                        <i class="fas fa-font"></i> فیلد متنی
                    </div>
                    <div class="element" draggable="true" data-type="number">
                        <i class="fas fa-hashtag"></i> فیلد عددی
                    </div>
                    <div class="element" draggable="true" data-type="email">
                        <i class="fas fa-envelope"></i> ایمیل
                    </div>
                    <div class="element" draggable="true" data-type="textarea">
                        <i class="fas fa-align-left"></i> متن چند خطی
                    </div>
                    <div class="element" draggable="true" data-type="select">
                        <i class="fas fa-list"></i> لیست کشویی
                    </div>
                    <div class="element" draggable="true" data-type="checkbox">
                        <i class="fas fa-check-square"></i> چک باکس
                    </div>
                    <div class="element" draggable="true" data-type="radio">
                        <i class="fas fa-dot-circle"></i> رادیو باتن
                    </div>
                    <div class="element" draggable="true" data-type="file">
                        <i class="fas fa-file"></i> آپلود فایل
                    </div>
                    <div class="element" draggable="true" data-type="date">
                        <i class="fas fa-calendar"></i> تاریخ
                    </div>
                </div>
            </div>

            <!-- Form Builder Area -->
            <div class="col-md-6 form-builder">
                <div class="form-header">
                    <h2>سازنده فرم</h2>
                    <div class="actions">
                        <button class="btn btn-primary" id="previewBtn">
                            <i class="fas fa-eye"></i> پیش‌نمایش
                        </button>
                        <button class="btn btn-success" id="saveBtn">
                            <i class="fas fa-save"></i> ذخیره
                        </button>
                    </div>
                </div>
                <div id="formContainer" class="form-container">
                    <div class="empty-state">
                        <i class="fas fa-arrow-left"></i>
                        <p>عناصر را از سمت راست به اینجا بکشید</p>
                    </div>
                </div>
            </div>

            <!-- Properties Panel -->
            <div class="col-md-3 properties-panel">
                <h3 class="text-center mb-4">ویژگی‌ها</h3>
                <div id="propertiesContainer">
                    <div class="empty-properties">
                        <p>یک عنصر را انتخاب کنید</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Preview Modal -->
    <div class="modal fade" id="previewModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">پیش‌نمایش فرم</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="previewForm"></div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
    <script src="script.js"></script>
</body>
</html> 